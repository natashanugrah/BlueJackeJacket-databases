CREATE DATABASE ProjectDB
GO
USE ProjectDB

CREATE TABLE Customer(
	CustomerId VARCHAR (5) PRIMARY KEY NOT NULL CHECK(CustomerId like 'CU[0-9][0-9][0-9]'),
	CustomerName VARCHAR (30),
	DateOfBirth DATE,
	Gender CHAR (6) CHECK (Gender IN ('Female' ,'Male'))
);

CREATE TABLE Staff(
	StaffId VARCHAR (5) PRIMARY KEY NOT NULL CHECK(StaffId like 'ST[0-9][0-9][0-9]'),
	StaffName VARCHAR (30),
	DateOfBirth DATE,
	Gender CHAR (6) CHECK (Gender IN ('Female' , 'Male')),
	Salary INT
);
drop table Staff

ALTER TABLE Staff ADD CONSTRAINT validasiNama CHECK(len(StaffName)>= 3)

ALTER TABLE Staff
ADD CONSTRAINT validasiSalary CHECK(Salary BETWEEN 1000000 AND 2000000)

CREATE TABLE Jacket(
	JacketId VARCHAR (5) PRIMARY KEY NOT NULL CHECK (JacketId like 'JA[0-9][0-9][0-9]'),
	JacketName VARCHAR (30),
	Price INT,
	Stock INT
);

CREATE TABLE Materials(
	MaterialsId VARCHAR (5) PRIMARY KEY NOT NULL CHECK(MaterialsId like 'MA[0-9][0-9][0-9]'),
	MaterialsName VARCHAR (30),
	Price INT ,
	Stock INT 
);

CREATE TABLE [Sales Transaction](
	SalesTransactionId VARCHAR (5) PRIMARY KEY NOT NULL CHECK(SalesTransactionId like 'SA[0-9][0-9][0-9]'),
	StaffId VARCHAR (5) FOREIGN KEY REFERENCES Staff,
	CustomerId VARCHAR (5) FOREIGN KEY REFERENCES Customer,
	TransactionDate DATE,
	JacketId VARCHAR (5) FOREIGN KEY REFERENCES Jacket,
	QuantityOfJacket INT
);

CREATE TABLE [Purchase Transaction] (
	PurchaseTransactionId VARCHAR(5) PRIMARY KEY NOT NULL CHECK(PurchaseTransactionId LIKE 'PR[0-9][0-9][0-9]'),
	StaffId VARCHAR (5) FOREIGN KEY REFERENCES Staff,
	MaterialsId VARCHAR(5) FOREIGN KEY REFERENCES Materials,
	TransactionDate DATE,
);

ALTER TABLE [Purchase Transaction] 
ADD VendorId VARCHAR(5) FOREIGN KEY REFERENCES Vendor(VendorId)


CREATE TABLE Vendor(
	VendorId VARCHAR (5) PRIMARY KEY NOT NULL CHECK(VendorId LIKE 'VE[0-9][0-9][0-9]'),
	VendorName VARCHAR (30),
	VendorAddress VARCHAR (30) CHECK (VendorAddress LIKE '%Street'),
	VendorEmail VARCHAR (30) CHECK (VendorEmail LIKE '%@%')
);

ALTER TABLE Vendor 
ADD CONSTRAINT validasiNama1 CHECK(len(VendorName)>= 3)

ALTER TABLE Jacket 
ADD CONSTRAINT validasiJc CHECK (Price >= 25000)



SELECT * FROM Customer
SELECT * FROM Staff
SELECT * FROM Jacket
SELECT * FROM [Sales Transaction]
SELECT * FROM Materials
SELECT * FROM Vendor
SELECT * FROM [Purchase Transaction]

DROP TABLE Customer
DROP TABLE Staff
DROP TABLE Jacket
DROP TABLE [Sales Transaction]
DROP TABLE Materials
DROP TABLE Vendor
DROP TABLE [Purchase Transaction]

DROP DATABASE ProjectDB



