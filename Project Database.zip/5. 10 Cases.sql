-- Query to answer the 10 cases


-- No 1 
SELECT Customer.CustomerName,CONVERT(VARCHAR(10), TransactionDate, 105) AS[TransactionDate],[TransactionQuantity]= SUM(QuantityOfJacket)
FROM  [Sales Transaction]
INNER JOIN Customer ON [Sales Transaction].CustomerID=Customer.CustomerID
WHERE  JacketId LIKE 'JA002' AND MONTH(TransactionDate) = 11
GROUP BY CustomerName, TransactionDate

-- No 2 
SELECT Vendor.VendorName,CONVERT(VARCHAR(10), TransactionDate, 105) AS[TransactionDate], [MaximumQuantity]=MAX(QuantityofMaterials)
FROM [Purchase Transaction]
INNER JOIN Vendor ON [Purchase Transaction].VendorId=Vendor.VendorId
WHERE MaterialsId LIKE 'MA001' AND DAY(TransactionDate)%2=0
GROUP BY VendorName, TransactionDate

-- No 3 
SELECT Vendor.VendorName, REPLACE((VendorAddress), 'Street', 'St') AS VendorAddress,
[TotalItem] = SUM(QuantityofMaterials), COUNT(PurchaseTransactionId) AS PurchaseTransactionId
FROM [Purchase Transaction]
INNER JOIN Vendor ON [Purchase Transaction].VendorId=Vendor.VendorId
WHERE VendorName LIKE 'PT.%' AND MONTH(TransactionDate)=10
GROUP BY VendorName, VendorAddress, TransactionDate

-- No 4  
SELECT Staff.StaffName, Customer.CustomerName, [Staff Gender]=LEFT(Staff.Gender, 1),
[Total Sales Transaction] = COUNT(SalesTransactionId)
FROM [Sales Transaction]
  JOIN Staff ON [Sales Transaction].StaffId=Staff.StaffId
JOIN Customer ON [Sales Transaction].CustomerId=Customer.CustomerId
WHERE DAY(TransactionDate)%2=0
GROUP BY StaffName, Staff.Gender, SalesTransactionId, Customer.CustomerName
HAVING SUM(QuantityOfJacket) >= 4

-- No 5 (how to using as, syntax first day in month, join 3 table)
SELECT UPPER(cs.CustomerName) AS Customer,
[Customer Gender]=LEFT(cs.Gender, 1)
FROM [Sales Transaction] st, (SELECT AVG(QuantityOfJacket) AS 
	 [Average Quantity] FROM [Sales Transaction]) AS A,
	 (SELECT QuantityOfJacket AS [Quantity Jacket] FROM [Sales Transaction] ) AS B
	JOIN Customer cs ON st.CustomerId=cs.CustomerId
WHERE MONTH(TransactionDate) = 1 AND QuantityOfJacket = A.[Average Quantity] > QuantityOfJacket = b.[Quantity Jacket]
GROUP BY CustomerName, TransactionDate

--AND DATEADD(month, DATEDIFF(month, 0, @mydate), 0) AS StartOfMonth

-- No 6(same problem )
SELECT Vendor.VendorName,CONVERT(VARCHAR(10), TransactionDate, 101) AS[PurchaseDate], LOWER(MaterialsName) AS [Material Name]
FROM [Purchase Transaction] pt, (SELECT (QuantityofMaterials),
	AVG(QuantityofMaterials) OVER () AS [Average Quantity] 
	FROM (([Purchase Transaction]
   INNER JOIN Vendor ON pt.VendorId=Vendor.VendorId)
INNER JOIN Materials ON pt.MaterialsId=Materials.MaterialsId)
WHERE QuantityofMaterials > [Average Quantity] AND VendorName LIKE '%Inc'
GROUP BY VendorName, MaterialsName, TransactionDate

-- No 7 
SELECT Customer.CustomerName, WHERE DATENAME(WEEKDAY, TransactionDate) = 'Monday', 





-- No 9 (punya natash)

--CREATE VIEW ViewPurchaseTransaction 
--AS SELECT Vendor.VendorName ,[Total Purchase Quantity] = SUM(QuantityofMaterials),
--[Total Purchase Transaction] = COUNT(PurchaseTransactionId) AS PurchaseTransactionId
--FROM [Purchase Transaction]
--INNER JOIN Vendor ON [Purchase Transaction].VendorId=Vendor.VendorId
--WHERE VendorName LIKE 'PT.' 
--GROUP BY VendorName
--HAVING [Total Purchase Transaction] > 2

-- ngga muncul tabelnya
CREATE VIEW ViewPurchaseTransaction AS
SELECT VendorName, SUM(QuantityofMaterials) AS[Total Purchase Quantity], COUNT(PurchaseTransactionId) AS [Purchase Transaction Id]
FROM [Purchase Transaction] pt
JOIN Vendor v ON pt.VendorId = v.VendorId
WHERE VendorName LIKE 'PT. '
GROUP BY VendorName


SELECT * FROM ViewPurchaseTransaction

DROP VIEW ViewPurchaseTransaction

-- No 10
CREATE VIEW [ViewSalesTransaction] AS 
SELECT Staff.StaffName, Customer.CustomerName,
[Total Sales Transaction]=COUNT(SalesTransactionId) AS SalesTransactionId,
[MaximumQuantity]=MAX(QuantityOfJacket)
FROM [Sales Transaction]
	JOIN Customer ON [Sales Transaction].CustomerID=Customer.CustomerID
JOIN Staff ON [Sales Transaction].StaffID=Staff.StaffID
WHERE CustomerName LIKE 'R%' 
GROUP BY Staff.StaffName, SalesTransactionId, Customer.CustomerName
HAVING [Total Sales Transaction] > 1

