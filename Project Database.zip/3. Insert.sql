USE Project

INSERT INTO Customer VALUES
('CU001','Natasha','20000923','Female'),
('CU002','Anugrah','19980220','Male'),
('CU003','Shafirra','20010504','Female'),
('CU004','Maurits','19960130','Male'),
('CU005','Rizal','19931001','Male'),
('CU006','Roito','19871116','Female'),
('CU007','Hakim','20020328','Female'),
('CU008','Hudaibi','19971202','Male'),
('CU009','Sanjaya','20050119','Male'),
('CU012','Noverya','19940617','Female')

SELECT*FROM Customer


INSERT INTO Staff VALUES
('ST012','ABc','19740516','Female',1200000),
('ST013','Hanbin','19901205','Male',2000000),
('ST014','Jinhwan','19860316','Male',1250000),
('ST015','Yoora','19890817','Female',1805000),
('ST016','Bobby','19921026','Male',1004500),
('ST017','Anjar','19730214','Female',1800000),
('ST018','Donghyuk','19850130','Male',2000000),
('ST019','Dinda','19940819','Female',1065000),
('ST021','June','19800713','Female',1905000),
('ST022','Jiyong','19880808','Male',1150000)

SELECT*FROM Staff


INSERT INTO Jacket VALUES
('JA001','Winbreaker',25000,20),
('JA002','BomberJacket',50000,70),
('JA003','VarsityJacket',28000,93),
('JA004','Leatherjacket',75000,6),
('JA005','SportsJacket',39000,24),
('JA006','ParkaJacket',82000,100),
('JA007','Duffle',100000,79),
('JA008','Pea Coat',150000,46),
('JA009','Trench Coat',97000,21),
('JA011','Mackintosh Coat',112000,13)

SELECT*FROM Jacket

INSERT INTO Materials VALUES
('MA001','Kain',90000,12),
('MA032','Terry',150000,150),
('MA033','Fleece',75000,80),
('MA034','Zipper',96000,164),
('MA035','Kancing',99000,45),
('MA036','Kanvas',118000,12),
('MA037','Taslan',250000,25),
('MA038','Mikro',356000,164),
('MA039','Parasut',118000,130),
('MA041','Corduroy',68000,133)

SELECT*FROM Materials

INSERT INTO [Sales Transaction] VALUES
('SA081','ST012','CU001','20190523','JA001',12),
('SA082','ST013','CU002','20181230','JA002',65),
('SA083','ST014','CU003','20180215','JA003',23),
('SA084','ST015','CU004','20181111','JA004',45),
('SA085','ST016','CU005','20180130','JA005',70),
('SA086','ST017','CU006','20190125','JA006',12),
('SA087','ST018','CU007','20190105','JA007',55),
('SA088','ST019','CU008','20190202','JA008',123),
('SA089','ST021','CU009','20180116','JA009',89),
('SA056','ST022','CU012','20180718','JA011',46),
('SA073','ST013','CU005','20170913','JA011',52),
('SA091','ST015','CU008','20180211','JA004',111),
('SA092','ST018','CU007','20171017','JA006',32),
('SA093','ST016','CU003','20170316','JA001',45),
('SA094','ST012','CU001','20180415','JA003',77)

--UPDATE [Sales Transaction] SET TransactionDate = '20181130' WHERE CustomerId = 'CU002'


SELECT*FROM [Sales Transaction]

INSERT INTO Vendor VALUES 
('VE051','Lebron','Earth Street','lebronjames@mail.com'),
('VE052','James','Semewew Street','jamescharles@mail.com'),
('VE053','Leeminho','Mars Street','LeeMinHo@mail.com'),
('VE054','RedVelvet','Jupiter Street','RedVelvet@mail.com'),
('VE055','Rick','Saturnus Street','ricktherick@mail.com'),
('VE056','Morthy','Uranus Street','mortthemighty@mail.com'),
('VE057','Summer','Pluto Street','summerthesister@mail.com'),
('VE058','Winter','Neptunus Street','winterthewinteer@mail.com'),
('VE059','Spring','Merkurius Street','springtime@mail.com'),
('VE060','Snowy','Khatulistiwa Street','sknowywood@mail.com')

SELECT*FROM Vendor


INSERT INTO [Purchase Transaction] VALUES
('PR041','ST012','MA031','20181209','VE051'),
('PR042','ST013','MA032','20171112','VE052'),
('PR043','ST014','MA033','20191121','VE053'),
('PR044','ST015','MA034','20191201','VE054'),
('PR045','ST016','MA035','20190411','VE055'),
('PR046','ST017','MA036','20190104','VE056'),
('PR047','ST018','MA037','20170425','VE057'),
('PR048','ST019','MA038','20180105','VE058'),
('PR049','ST021','MA039','20170815','VE059'),
('PR050','ST022','MA033','20180619','VE060'),
('PR051','ST013','MA041','20170423','VE055'),
('PR052','ST016','MA032','20180311','VE057'),
('PR053','ST018','MA038','20170209','VE051'),
('PR054','ST012','MA037','20171001','VE060'),
('PR055','ST019','MA041','20170908','VE059')

SELECT*FROM [Purchase Transaction]